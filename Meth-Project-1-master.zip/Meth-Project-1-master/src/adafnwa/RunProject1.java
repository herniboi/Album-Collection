package adafnwa;

/**
 * Driver class to run collection manager
 * @author Andy Li, Henry Lin
 */
public class RunProject1 {
    /**
     * runs collection manager
     * @param args
     */
    public static void main(String[] args) {
        new CollectionManager().run();
    }
}
